Baow 文档编辑器在生成网页的时候采用 `Sphinx`_ 编写文档的方式进行。 `Sphinx`_ 源于 Python 编程语言当中支持的 reStructuredText 。

reStructuredText 是一种简单易用的标记语言，通过按照 reStructuredText 规定好的语法进行编写，就可以生成网页在内的多种格式的文档。  `Sphinx`_  对 reStructuredText 进行了扩展，加入了更多的标记，然后可以将多个文件串联在一起，形成网页文件。 Baow 采用  `Sphinx`_ 生成网页的方式，只需要在 Firefox 浏览器当中编写文档就可以了，简化了 Sphinx 编写文档的方式。

.. seealso::

     `Sphinx`_ 

Baow 和 `Sphinx`_ 是完全兼容的，改进了编写的方式，只要按照树状结构组织章节，就能自动生成目录结构。

这部分内容正在编写当中，将详细讲述 Baow 支持的所有标记和语法，以及 Baow 编写网页时的方式。英文版当中的内容比较全，请查看 `英文版本 <http://www.baow.com/help/data/20110525114558/index.html>`_ 。

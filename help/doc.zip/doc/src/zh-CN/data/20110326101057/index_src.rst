1. 安装  `Firefox 浏览器`_ .
2. 安装  `baow`_ 扩展，并重启Firefox。

如果您想生成网页文件，则还需要：

3. 安装  `Python 语言`_ 。大多数 Linux 之类的系统已经安装了Python，可能不需要再安装了，但版本可能不是最新的。
4. 安装  `Sphinx 模块`_ ，或通过 easy_install 如下方式安装::
     
        easy_install -U Sphinx

     
   easy_install 下载的地方是： `Python Package Index : setuptools`_ 

   最后，应该可以找到如下的Sphinx命令::

         /usr/bin/sphinx-build



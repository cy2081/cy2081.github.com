1. 安装  `Firefox 浏览器`_ 。
2. 安装  `baow`_ 扩展，并重启Firefox。

如果您想生成网页文件，则还需要：

3. 安装  `Python 语言`_ 。
4. 安装  `Sphinx 模块`_ ，或通过 easy_install 如下方式安装::
     
        easy_install -U Sphinx

     
   easy_install 下载的地方是： `Python Package Index : setuptools`_ 

   最后，应该可以在 Python 的安装目录下边找到如下的Sphinx命令::

         C:\Python27\Scripts\sphinx-build.exe



编辑列表时，只要按照固定的格式，就会显示出特定的效果。只要在文字前边加上特定的符号，这些符号包括： "*", "+", "-", "•", "‣", or "⁃"， 并进行缩进即可，或者用数字，也可以用  ``#`` 表示自动编号。例如::


   * This is a bulleted list.
   * It has two items, the second
     item uses two lines.

   1. This is a numbered list.
   2. It has two items too.

   #. This is a numbered list.
   #. It has two items too.

注意包含下级列表时要加入空行::

   * this is
   * a list

     * with a nested list
     * and some subitems

   * and here the parent list continues

定义型列表按照如下格式::

   term (up to a line of text)
      Definition of the term, which must be indented

      and can even consist of multiple paragraphs

   next term
      Description.

表示引用的段落只要前边加上空格缩进就可以了。


如果需要保留换行格式，前边加上 | ::

   | These lines are
   | broken exactly like in
   | the source file.

字段列表， 例如::

   :Date: 2001-08-16
   :Version: 1
   :Authors: - Me
             - Myself
             - I
   :Indentation: Since the field marker may be quite long, the second
      and subsequent lines of the field body do not have to line up
      with the first line, but they must be indented relative to the
      field name marker, and they must line up with each other.
   :Parameter i: integer

选项列表，例如::

  -a         Output all.
  -b         Output both (this description is
             quite long).
  -c arg     Output just arg.
  --long     Output all day long.

  -p         This option has two paragraphs in the description.
             This is the first.

引用列表，要表示引用时，注意要加上 ``::`` 符号，例如::

  John Doe wrote::

  >> Great idea!
  >
  > Why didn't I think of that?

  You just did!  ;-)

Doctest 列表，注意要加上 ``::`` ，例如::

  The following is a literal block::

      >>> This is not recognized as a doctest block by
      reStructuredText.  It *will* be recognized by the doctest
      module, though!


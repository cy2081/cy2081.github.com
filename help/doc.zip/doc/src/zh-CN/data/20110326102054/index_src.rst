在项目管理窗口当中，点击  ``路径`` 按钮，在弹出的窗口当中，首先输入基本的路径信息。 通过点击  :guilabel:`选择`  按钮可以直接选择路径。

 |选择路径| 

说明如下:

   **数据保存到** :
    所有数据都保存到这个目录下边。
   **Sphinx 命令路径** :
    Sphinx 的命令文件，Windows 当中一般是::

       C:\Python27\Scripts\sphinx-build.exe

    Linux, BSD 等系统当中一般是::

       /usr/bin/sphinx-build 



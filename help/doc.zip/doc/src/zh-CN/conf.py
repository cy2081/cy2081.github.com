# -*- coding: utf-8 -*-

import sys, os
import re
import sphinx
sys.path.append('/home/duws/baow.com/lib/chinese/')

project = u'''Baow 文档编辑器使用说明'''
copyright = u'''川越，使用Baow文档编辑器生成'''
#release = None
version = u'''3.1'''
language = '''zh_CN'''
#today = None
today_fmt = '''%Y - %m - %d'''
highlight_language = '''python'''
pygments_style = '''sphinx'''
show_authors = False
add_function_parentheses = True
add_module_names = True
modindex_common_prefix = []
trim_footnote_reference_space = False
gettext_compact = False
trim_doctest_flags = True
extensions = []
exclude_patterns = ['_build']
locale_dirs = []
templates_path = ['_templates']
#template_bridge = None
#rst_epilog = None
#rst_epilog_temp = None
#rst_prolog = None
rst_prolog_temp = u'''__BR____BR__'''
primary_domain = '''py'''
#default_role = None
keep_warnings = False
#needs_sphinx = None
nitpicky = False
text_newlines = '''native'''
html_title = u'''Baow 文档编辑器'''
html_theme = '''default'''
html_theme_options = {}
html_theme_path = []
#html_style = None
#html_short_title = None
html_context = {}
#html_logo = None
#html_favicon = None
html_static_path = ['static']
html_last_updated_fmt = '''%b %d, %Y'''
html_use_smartypants = True
#html_add_permalinks = None
html_sidebars = {'**': ['globaltoc.html', 'sourcelink.html'], 'using/windows': ['windowssidebar.html'], }
html_additional_pages = {}
html_domain_indices = True
html_use_index = True
html_split_index = False
html_copy_source = True
html_show_sourcelink = True
#html_use_opensearch = None
html_file_suffix = '''.html'''
#html_link_suffix = None
#html_translator_class = None
html_show_copyright = True
html_show_sphinx = True
html_output_encoding = '''utf-8'''
html_compact_lists = True
html_secnumber_suffix = '''. '''
htmlhelp_basename = '''pydoc'''
#epub_basename = None
epub_theme = '''epub'''
#epub_title = None
#epub_author = None
#epub_language = None
#epub_publisher = None
#epub_copyright = None
#epub_identifier = None
#epub_scheme = None
#epub_uid = None
epub_pre_files = []
epub_post_files = []
epub_exclude_files = []
epub_cover = ()
epub_tocdepth = '''3'''
epub_tocdup = True
latex_documents = ()
#latex_logo = None
latex_use_parts = False
latex_appendices = []
latex_domain_indices = True
latex_show_pagerefs = False
#latex_show_urls = None
latex_elements = {}
latex_docclass = {}
latex_additional_files = []
man_pages = ()
man_show_urls = False
baow_keywords = u''''''
baow_comment = u''''''
baow_description = u''''''
baow_crumb = u'''Baow 文档编辑器使用说明'''
baow_layout = '''layout.html'''
baow_content = '''page.html'''
baow_h_list_style = '''h_list_1'''
#baow_id = None
baow_show_num = False
baow_show_date = False
baow_show_update = False
baow_show_heng = False
baow_show_icon = False
baow_special = False


# not edit following lines, it's Baow default base settings.
source_suffix = '.bao'
master_doc = 'index'

todo_include_todos = True
extlinks = {'duref': ('../20110525164311/'
                      'index.html#%s', ''),
            'durole': ('http://docutils.sourceforge.net/docs/ref/rst/'
                       'roles.html#%s', ''),
            'dudir': ('../20110525173013/'
                      'index.html#%s', '')}


Signatures of functions, methods and class constructors can be given like they
would be written in Python, with the exception that optional parameters can be
indicated by brackets::

   .. py:function:: compile(source[, filename[, symbol]])

It is customary to put the opening bracket before the comma.  In addition to
this "nested" bracket style, a "flat" style can also be used, due to the fact
that most optional parameters can be given independently::

   .. py:function:: compile(source[, filename, symbol])

Default values for optional arguments can be given (but if they contain commas,
they will confuse the signature parser).  Python 3-style argument annotations
can also be given as well as return type annotations::

   .. py:function:: compile(source : string[, filename, symbol]) -> ast object

Doctree element: system_message, problematic.

Markup errors are handled according to the specification in `PEP
258`_.
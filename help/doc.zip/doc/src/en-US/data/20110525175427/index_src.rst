:Directive Type: "date"
:Doctree Element: Text
:Directive Arguments: One, optional (date format).
:Directive Options: None.
:Directive Content: None.

The "date" directive generates the current local date and inserts it
into the document as text.  This directive may be used in substitution
definitions only.

The optional directive content is interpreted as the desired date
format, using the same codes as Python's time.strftime function.  The
default format is "%Y-%m-%d" (ISO 8601 date), but time fields can also
be used.  Examples::

    .. |date| date::
    .. |time| date:: %H:%M

    Today's date is |date|.

    This document was generated on |date| at |time|.


You can write documents by adding objects, like Document, Summary, Image, File, Bookmark, Separator, Folder or Source File, and referenced with  `Sphinx Markup`_ (ReST).

 * Document: 
    you can edit with it, and add sub document.
 * Summary: 
    It's text paragraph, and will be inserted into document.
 * Image:
    You can add images by select from local file or saved from web pages, and referenced globally in ReST.
 * File:
    You can add files by select from local file or saved from web pages, and referenced globally in ReST.
 * Bookmark:
    Web links with title and URL, and referenced globally in ReST.
 * Source File:
    You can edit source code, like C++, Java, PHP, Python.
 * Separator:
    It's used for partition.
 * Folder:
    Help you organizing resources.

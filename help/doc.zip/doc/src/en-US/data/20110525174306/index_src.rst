:Directive Type: "contents"
:Doctree Elements: pending, topic
:Directive Arguments: One, optional: title.
:Directive Options: Possible.
:Directive Content: None.

The "contents" directive generates a table of contents (TOC) in a
topic_.  Topics, and therefore tables of contents, may occur anywhere
a section or transition may occur.  Body elements and topics may not
contain tables of contents.

Here's the directive in its simplest form::

    .. contents::

Language-dependent boilerplate text will be used for the title.  The
English default title text is "Contents".

An explicit title may be specified::

    .. contents:: Table of Contents

The title may span lines, although it is not recommended::

    .. contents:: Here's a very long Table of
       Contents title

Options may be specified for the directive, using a field list::

    .. contents:: Table of Contents
       :depth: 2

If the default title is to be used, the options field list may begin
on the same line as the directive marker::

    .. contents:: :depth: 2

The following options are recognized:

``depth`` : integer
    The number of section levels that are collected in the table of
    contents.  The default is unlimited depth.

``local`` : flag (empty)
    Generate a local table of contents.  Entries will only include
    subsections of the section in which the directive is given.  If no
    explicit title is given, the table of contents will not be titled.

``backlinks`` : "entry" or "top" or "none"
    Generate links from section headers back to the table of contents
    entries, the table of contents itself, or generate no backlinks.

``class`` : text
    Set a "classes" attribute value on the topic element.  See the
    class_ directive below.
:Directive Type: "title"
:Doctree Element: None.
:Directive Arguments: 1, required (the title text).
:Directive Options: None.
:Directive Content: None.

The "title" directive specifies the document title as metadata, which
does not become part of the document body.  It overrides a
document-supplied title.  For example, in HTML output the metadata
document title appears in the title bar of the browser window.
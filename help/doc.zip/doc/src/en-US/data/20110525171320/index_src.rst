Doctree element: substitution_definition.

Substitution definitions are indicated by an explicit markup start
(".. ") followed by a vertical bar, the substitution text, another
vertical bar, whitespace, and the definition block.  Substitution text
may not begin or end with whitespace.  A substitution definition block
contains an embedded inline-compatible directive (without the leading
".. "), such as "image_" or "replace_".  For example::

    The |biohazard| symbol must be used on containers used to
    dispose of medical waste.

    .. |biohazard| image:: biohazard.png

It is an error for a substitution definition block to directly or
indirectly contain a circular substitution reference.

`Substitution references`_ are replaced in-line by the processed
contents of the corresponding definition (linked by matching
substitution text).  Matches are case-sensitive but forgiving; if no
exact match is found, a case-insensitive comparison is attempted.

Substitution definitions allow the power and flexibility of
block-level directives_ to be shared by inline text.  They are a way
to include arbitrarily complex inline structures within text, while
keeping the details out of the flow of text.  They are the equivalent
of SGML/XML's named entities or programming language macros.

Without the substitution mechanism, every time someone wants an
application-specific new inline structure, they would have to petition
for a syntax change.  In combination with existing directive syntax,
any inline structure can be coded without new syntax (except possibly
a new directive).

Syntax diagram::

    +-------+-----------------------------------------------------+
    | ".. " | "|" substitution text "| " directive type "::" data |
    +-------+ directive block                                     |
            |                                                     |
            +-----------------------------------------------------+

Following are some use cases for the substitution mechanism.  Please
note that most of the embedded directives shown are examples only and
have not been implemented.

Objects
    Substitution references may be used to associate ambiguous text
    with a unique object identifier.

    For example, many sites may wish to implement an inline "user"
    directive::

        |Michael| and |Jon| are our widget-wranglers.

        .. |Michael| user:: mjones
        .. |Jon|     user:: jhl

    Depending on the needs of the site, this may be used to index the
    document for later searching, to hyperlink the inline text in
    various ways (mailto, homepage, mouseover Javascript with profile
    and contact information, etc.), or to customize presentation of
    the text (include username in the inline text, include an icon
    image with a link next to the text, make the text bold or a
    different color, etc.).

    The same approach can be used in documents which frequently refer
    to a particular type of objects with unique identifiers but
    ambiguous common names.  Movies, albums, books, photos, court
    cases, and laws are possible.  For example::

        |The Transparent Society| offers a fascinating alternate view
        on privacy issues.

        .. |The Transparent Society| book:: isbn=0738201448

    Classes or functions, in contexts where the module or class names
    are unclear and/or interpreted text cannot be used, are another
    possibility::

        4XSLT has the convenience method |runString|, so you don't
        have to mess with DOM objects if all you want is the
        transformed output.

        .. |runString| function:: module=xml.xslt class=Processor

Images
    Images are a common use for substitution references::

        West led the |H| 3, covered by dummy's |H| Q, East's |H| K,
        and trumped in hand with the |S| 2.

        .. |H| image:: /images/heart.png
           :height: 11
           :width: 11
        .. |S| image:: /images/spade.png
           :height: 11
           :width: 11

        * |Red light| means stop.
        * |Green light| means go.
        * |Yellow light| means go really fast.

        .. |Red light|    image:: red_light.png
        .. |Green light|  image:: green_light.png
        .. |Yellow light| image:: yellow_light.png

        |-><-| is the official symbol of POEE_.

        .. |-><-| image:: discord.png
        .. _POEE: http://www.poee.org/

    The "image_" directive has been implemented.

Styles [#]_
    Substitution references may be used to associate inline text with
    an externally defined presentation style::

        Even |the text in Texas| is big.

        .. |the text in Texas| style:: big

    The style name may be meaningful in the context of some particular
    output format (CSS class name for HTML output, LaTeX style name
    for LaTeX, etc), or may be ignored for other output formats (such
    as plaintext).

    .. @@@ This needs to be rethought & rewritten or removed:

       Interpreted text is unsuitable for this purpose because the set
       of style names cannot be predefined - it is the domain of the
       content author, not the author of the parser and output
       formatter - and there is no way to associate a style name
       argument with an interpreted text style role.  Also, it may be
       desirable to use the same mechanism for styling blocks::

           .. style:: motto
              At Bob's Underwear Shop, we'll do anything to get in
              your pants.

           .. style:: disclaimer
              All rights reversed.  Reprint what you like.

    .. [#] There may be sufficient need for a "style" mechanism to
       warrant simpler syntax such as an extension to the interpreted
       text role syntax.  The substitution mechanism is cumbersome for
       simple text styling.

Templates
    Inline markup may be used for later processing by a template
    engine.  For example, a Zope_ author might write::

        Welcome back, |name|!

        .. |name| tal:: replace user/getUserName

    After processing, this ZPT output would result::

        Welcome back,
        <span tal:replace="user/getUserName">name</span>!

    Zope would then transform this to something like "Welcome back,
    David!" during a session with an actual user.

Replacement text
    The substitution mechanism may be used for simple macro
    substitution.  This may be appropriate when the replacement text
    is repeated many times throughout one or more documents,
    especially if it may need to change later.  A short example is
    unavoidably contrived::

        |RST|_ is a little annoying to type over and over, especially
        when writing about |RST| itself, and spelling out the
        bicapitalized word |RST| every time isn't really necessary for
        |RST| source readability.

        .. |RST| replace:: reStructuredText
        .. _RST: http://docutils.sourceforge.net/rst.html

    Note the trailing underscore in the first use of a substitution
    reference.  This indicates a reference to the corresponding
    hyperlink target.

    Substitution is also appropriate when the replacement text cannot
    be represented using other inline constructs, or is obtrusively
    long::

        But still, that's nothing compared to a name like
        |j2ee-cas|__.

        .. |j2ee-cas| replace::
           the Java `TM`:super: 2 Platform, Enterprise Edition Client
           Access Services
        __ http://developer.java.sun.com/developer/earlyAccess/
           j2eecas/

    The "replace_" directive has been implemented.


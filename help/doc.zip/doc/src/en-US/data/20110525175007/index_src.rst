:Directive Type: "target-notes"
:Doctree Elements: pending, footnote, footnote_reference
:Directive Arguments: None.
:Directive Options: Possible.
:Directive Content: None.

The "target-notes" directive creates a footnote for each external
target in the text, and corresponding footnote references after each
reference.  For every explicit target (of the form, ``.. _target name:
URL``) in the text, a footnote will be generated containing the
visible URL as content.

The following option is recognized:

``class`` : text
    Set a "classes" attribute value on all footnote_reference elements.
    See the class_ directive below.
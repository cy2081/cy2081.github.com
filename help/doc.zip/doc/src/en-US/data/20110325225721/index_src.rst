Firefox extension:   `click here <http://www.baow.com/help/baow-3.1.xpi>`_  
   Version: |version|

Demo project: `click here <http://www.baow.com/help/doc.zip>`_ 
  Unpack it, and open Baow projects management window, click  **Root Path**  button, and  select unpacked path  ``doc/src``. Select a project , and apply it.

  
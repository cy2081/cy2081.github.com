Click button  |generate button|  from the sidebar.

   |generate| 

Select your output path. It will be a moment to generate final pages.


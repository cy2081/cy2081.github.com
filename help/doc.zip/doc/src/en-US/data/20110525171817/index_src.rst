Doctree element: literal.

Start-string = end-string = "``".

Text enclosed by double-backquotes is treated as inline literals::

    This text is an example of ``inline literals``.

Inline literals may contain any characters except two adjacent
backquotes in an end-string context (according to the recognition
rules above).  No markup interpretation (including backslash-escape
interpretation) is done within inline literals.

Line breaks are *not* preserved in inline literals.  Although a
reStructuredText parser will preserve runs of spaces in its output,
the final representation of the processed document is dependent on the
output formatter, thus the preservation of whitespace cannot be
guaranteed.  If the preservation of line breaks and/or other
whitespace is important, `literal blocks`_ should be used.

Inline literals are useful for short code snippets.  For example::

    The regular expression ``[+-]?(\d+(\.\d*)?|\.\d+)`` matches
    floating-point numbers (without exponents).
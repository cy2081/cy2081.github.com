You can add images and files from local directory or web pages.

Add local file:

 Click menu   :menuselection:`New Image` or :menuselection:`New File` from the sidebar, and select your local file or input a file URL.

Save web file:

 move your mouse on image, link, web pages, and right click , you see this menu:

 |save image| 

After done, you can reference it by copy ReST text from pop up menu or property dialog.



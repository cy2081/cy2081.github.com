:Directive Type: "topic"
:Doctree Element: topic
:Directive Arguments: 1, required (topic title).
:Directive Options: Possible.
:Directive Content: Interpreted as the topic body.

A topic is like a block quote with a title, or a self-contained
section with no subsections.  Use the "topic" directive to indicate a
self-contained idea that is separate from the flow of the document.
Topics may occur anywhere a section or transition may occur.  Body
elements and topics may not contain nested topics.

The directive's sole argument is interpreted as the topic title; the
next line must be blank.  All subsequent lines make up the topic body,
interpreted as body elements.  For example::

    .. topic:: Topic Title

        Subsequent indented lines comprise
        the body of the topic, and are
        interpreted as body elements.

The following option is recognized:

``class`` : text
    Set a "classes" attribute value on the topic element.  See the
    class_ directive below.

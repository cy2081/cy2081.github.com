Doctree element: substitution_reference, reference.

Start-string = "|", end-string = "|" (optionally followed by "_" or
"__").

Vertical bars are used to bracket the substitution reference text.  A
substitution reference may also be a hyperlink reference by appending
a "_" (named) or "__" (anonymous) suffix; the substitution text is
used for the reference text in the named case.

The processing system replaces substitution references with the
processed contents of the corresponding `substitution definitions`_
(which see for the definition of "correspond").  Substitution
definitions produce inline-compatible elements.

Examples::

    This is a simple |substitution reference|.  It will be replaced by
    the processing system.

    This is a combination |substitution and hyperlink reference|_.  In
    addition to being replaced, the replacement text or element will
    refer to the "substitution and hyperlink reference" target.


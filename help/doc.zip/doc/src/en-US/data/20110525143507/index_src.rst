.. confval:: extensions

   A list of strings that are module names of Sphinx extensions.  These can be
   extensions coming with Sphinx (named ``sphinx.ext.*``) or custom ones.

   Note that you can extend :data:`sys.path` within the conf file if your
   extensions live in another directory -- but make sure you use absolute paths.
   If your extension path is relative to the :term:`configuration directory`,
   use :func:`os.path.abspath` like so::

      import sys, os

      sys.path.append(os.path.abspath('sphinxext'))

      extensions = ['extname']

   That way, you can load an extension called ``extname`` from the subdirectory
   ``sphinxext``.

   The configuration file itself can be an extension; for that, you only need to
   provide a :func:`setup` function in it.

.. confval:: source_suffix

   The file name extension of source files.  Only files with this suffix will be
   read as sources.  Default is ``'.rst'``.

.. confval:: source_encoding

   The encoding of all reST source files.  The recommended encoding, and the
   default value, is ``'utf-8-sig'``.

   .. versionadded:: 0.5
      Previously, Sphinx accepted only UTF-8 encoded sources.

.. confval:: master_doc

   The document name of the "master" document, that is, the document that
   contains the root :rst:dir:`toctree` directive.  Default is ``'contents'``.

.. confval:: exclude_patterns

   A list of glob-style patterns that should be excluded when looking for source
   files. [1]_ They are matched against the source file names relative to the
   source directory, using slashes as directory separators on all platforms.

   Example patterns:

   - ``'library/xml.rst'`` -- ignores the ``library/xml.rst`` file (replaces
     entry in :confval:`unused_docs`)
   - ``'library/xml'`` -- ignores the ``library/xml`` directory (replaces entry
     in :confval:`exclude_trees`)
   - ``'library/xml*'`` -- ignores all files and directories starting with
     ``library/xml``
   - ``'**/.svn'`` -- ignores all ``.svn`` directories (replaces entry in
     :confval:`exclude_dirnames`)

   :confval:`exclude_patterns` is also consulted when looking for static files
   in :confval:`html_static_path`.

   .. versionadded:: 1.0

.. confval:: unused_docs

   A list of document names that are present, but not currently included in the
   toctree.  Use this setting to suppress the warning that is normally emitted
   in that case.

   .. deprecated:: 1.0
      Use :confval:`exclude_patterns` instead.

.. confval:: exclude_trees

   A list of directory paths, relative to the source directory, that are to be
   recursively excluded from the search for source files, that is, their
   subdirectories won't be searched too.  The default is ``[]``.

   .. versionadded:: 0.4

   .. deprecated:: 1.0
      Use :confval:`exclude_patterns` instead.

.. confval:: exclude_dirnames

   A list of directory names that are to be excluded from any recursive
   operation Sphinx performs (e.g. searching for source files or copying static
   files).  This is useful, for example, to exclude version-control-specific
   directories like ``'CVS'``.  The default is ``[]``.

   .. versionadded:: 0.5

   .. deprecated:: 1.0
      Use :confval:`exclude_patterns` instead.

.. confval:: locale_dirs

   .. versionadded:: 0.5

   Directories in which to search for additional Sphinx message catalogs (see
   :confval:`language`), relative to the source directory.  The directories on
   this path are searched by the standard :mod:`gettext` module for a text
   domain of ``sphinx``; so if you add the directory :file:`./locale` to this
   settting, the message catalogs (compiled from ``.po`` format using
   :program:`msgfmt`) must be in
   :file:`./locale/{language}/LC_MESSAGES/sphinx.mo`.

   The default is ``[]``.

.. confval:: templates_path

   A list of paths that contain extra templates (or templates that overwrite
   builtin/theme-specific templates).  Relative paths are taken as relative to
   the configuration directory.

.. confval:: template_bridge

   A string with the fully-qualified name of a callable (or simply a class) that
   returns an instance of :class:`~sphinx.application.TemplateBridge`.  This
   instance is then used to render HTML documents, and possibly the output of
   other builders (currently the changes builder).  (Note that the template
   bridge must be made theme-aware if HTML themes are to be used.)

.. confval:: rst_epilog

   .. index:: pair: global; substitutions

   A string of reStructuredText that will be included at the end of every source
   file that is read.  This is the right place to add substitutions that should
   be available in every file.  An example::

      rst_epilog = """
      .. |psf| replace:: Python Software Foundation
      """

   .. versionadded:: 0.6

.. confval:: rst_prolog

   A string of reStructuredText that will be included at the beginning of every
   source file that is read.

   .. versionadded:: 1.0

.. confval:: primary_domain

   .. index:: default; domain
              primary; domain

   The name of the default :ref:`domain <domains>`.  Can also be ``None`` to
   disable a default domain.  The default is ``'py'``.  Those objects in other
   domains (whether the domain name is given explicitly, or selected by a
   :rst:dir:`default-domain` directive) will have the domain name explicitly
   prepended when named (e.g., when the default domain is C, Python functions
   will be named "Python function", not just "function").

   .. versionadded:: 1.0

.. confval:: default_role

   .. index:: default; role

   The name of a reST role (builtin or Sphinx extension) to use as the default
   role, that is, for text marked up ```like this```.  This can be set to
   ``'py:obj'`` to make ```filter``` a cross-reference to the Python function
   "filter".  The default is ``None``, which doesn't reassign the default role.

   The default role can always be set within individual documents using the
   standard reST :rst:dir:`default-role` directive.

   .. versionadded:: 0.4

.. confval:: keep_warnings

   If true, keep warnings as "system message" paragraphs in the built documents.
   Regardless of this setting, warnings are always written to the standard error
   stream when ``sphinx-build`` is run.

   The default is ``False``, the pre-0.5 behavior was to always keep them.

   .. versionadded:: 0.5

.. confval:: needs_sphinx

   If set to a ``major.minor`` version string like ``'1.1'``, Sphinx will
   compare it with its version and refuse to build if it is too old.  Default is
   no requirement.

   .. versionadded:: 1.0

.. confval:: nitpicky

   If true, Sphinx will warn about *all* references where the target cannot be
   found.  Default is ``False``.  You can activate this mode temporarily using
   the :option:`-n` command-line switch.

   .. versionadded:: 1.0


:Directive Type: "compound"
:Doctree Element: compound
:Directive Arguments: None.
:Directive Options: Possible.
:Directive Content: Interpreted as body elements.

(New in Docutils 0.3.6)

The "compound" directive is used to create a compound paragraph, which
is a single logical paragraph containing multiple physical body
elements such as simple paragraphs, literal blocks, tables, lists,
etc., instead of directly containing text and inline elements.  For
example::

    .. compound::

       The 'rm' command is very dangerous.  If you are logged
       in as root and enter ::

           cd /
           rm -rf *

       you will erase the entire contents of your file system.

In the example above, a literal block is "embedded" within a sentence
that begins in one physical paragraph and ends in another.

.. note::

   The "compound" directive is *not* a generic block-level container
   like HTML's ``<div>`` element.  Do not use it only to group a
   sequence of elements, or you may get unexpected results.

   If you need a generic block-level container, please use the
   container_ directive, described below.

Compound paragraphs are typically rendered as multiple distinct text
blocks, with the possibility of variations to emphasize their logical
unity:

* If paragraphs are rendered with a first-line indent, only the first
  physical paragraph of a compound paragraph should have that indent
  -- second and further physical paragraphs should omit the indents;
* vertical spacing between physical elements may be reduced;
* and so on.

The following option is recognized:

``class`` : text
    Set a "classes" attribute value on the compound element.  See the
    class_ directive below.


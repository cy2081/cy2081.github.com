:Directive Type: "sectnum" or "section-autonumbering" (synonyms)
:Doctree Elements: pending, generated
:Directive Arguments: None.
:Directive Options: Possible.
:Directive Content: None.

The "sectnum" (or "section-autonumbering") directive automatically numbers
sections and subsections in a document (if not disabled by the
``--no-section-numbering`` command line option or the `sectnum_xform`_
configuration setting).

Section numbers are of the "multiple enumeration" form, where each
level has a number, separated by periods.  For example, the title of section
1, subsection 2, subsubsection 3 would have "1.2.3" prefixed.

The "sectnum" directive does its work in two passes: the initial parse
and a transform.  During the initial parse, a "pending" element is
generated which acts as a placeholder, storing any options internally.
At a later stage in the processing, the "pending" element triggers a
transform, which adds section numbers to titles.  Section numbers are
enclosed in a "generated" element, and titles have their "auto"
attribute set to "1".

The following options are recognized:

``depth`` : integer
    The number of section levels that are numbered by this directive.
    The default is unlimited depth.

``prefix`` : string
    An arbitrary string that is prefixed to the automatically
    generated section numbers.  It may be something like "3.2.", which
    will produce "3.2.1", "3.2.2", "3.2.2.1", and so on.  Note that
    any separating punctuation (in the example, a period, ".") must be
    explicitly provided.  The default is no prefix.

``suffix`` : string
    An arbitrary string that is appended to the automatically
    generated section numbers.  The default is no suffix.

``start`` : integer
    The value that will be used for the first section number.
    Combined with ``prefix``, this may be used to force the right
    numbering for a document split over several source files.  The
    default is 1.

.. _sectnum_xform: ../../user/config.html#sectnum-xform
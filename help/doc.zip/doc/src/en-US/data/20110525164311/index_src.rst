.. highlightlang:: rest

reStructuredText_ is plaintext that uses simple and intuitive
constructs to indicate the structure of a document.  These constructs
are equally easy to read in raw and processed forms.  This document is
itself an example of reStructuredText (raw, if you are reading the
text file, or processed, if you are reading an HTML document, for
example).  The reStructuredText parser is a component of Docutils_.

Simple, implicit markup is used to indicate special constructs, such
as section headings, bullet lists, and emphasis.  The markup used is
as minimal and unobtrusive as possible.  Less often-used constructs
and extensions to the basic reStructuredText syntax may have more
elaborate or explicit markup.

reStructuredText is applicable to documents of any length, from the
very small (such as inline program documentation fragments, e.g.
Python docstrings) to the quite large (this document).

The first section gives a quick overview of the syntax of the
reStructuredText markup by example.  A complete specification is given
in the `Syntax Details`_ section.

`Literal blocks`_ (in which no markup processing is done) are used for
examples throughout this document, to illustrate the plaintext markup.
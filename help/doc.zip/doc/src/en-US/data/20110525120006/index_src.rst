reST supports "substitutions" (:duref:`ref <substitution-definitions>`), which
are pieces of text and/or markup referred to in the text by ``|name|``.  They
are defined like footnotes with explicit markup blocks, like this::

   .. |name| replace:: replacement *text*

or this::

   .. |caution| image:: warning.png
                :alt: Warning!

See the :duref:`reST reference for substitutions <substitution-definitions>`
for details.

If you want to use some substitutions for all documents, put them into
:confval:`rst_prolog` or put them into a separate file and include it into all
documents you want to use them in, using the :rst:dir:`include` directive.  (Be
sure to give the include file a file name extension differing from that of other
source files, to avoid Sphinx finding it as a standalone document.)

Sphinx defines some default substitutions, see :ref:`default-substitutions`.

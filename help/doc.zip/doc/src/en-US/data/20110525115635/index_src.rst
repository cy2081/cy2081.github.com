Internal linking is done via a special reST role provided by Sphinx, see the
section on specific markup, :ref:`ref-role`.
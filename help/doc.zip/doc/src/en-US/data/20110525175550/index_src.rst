:Directive Type: "raw"
:Doctree Element: raw
:Directive Arguments: One or more, required (output format types).
:Directive Options: Possible.
:Directive Content: Stored verbatim, uninterpreted.  None (empty) if a
                    "file" or "url" option given.

.. WARNING::

   The "raw" directive represents a potential security hole.  It can
   be disabled with the "raw_enabled_" or "file_insertion_enabled_"
   runtime settings.

   .. _raw_enabled: http://docutils.sourceforge.net/docs/user/config.html#raw-enabled

.. Caution::

   The "raw" directive is a stop-gap measure allowing the author to
   bypass reStructuredText's markup.  It is a "power-user" feature
   that should not be overused or abused.  The use of "raw" ties
   documents to specific output formats and makes them less portable.

   If you often need to use the "raw" directive or a "raw"-derived
   interpreted text role, that is a sign either of overuse/abuse or
   that functionality may be missing from reStructuredText.  Please
   describe your situation in a message to the Docutils-users_ mailing
   list.

.. _Docutils-users: http://docutils.sourceforge.net/docs/user/mailing-lists.html#docutils-users

The "raw" directive indicates non-reStructuredText data that is to be
passed untouched to the Writer.  The names of the output formats are
given in the directive arguments.  The interpretation of the raw data
is up to the Writer.  A Writer may ignore any raw output not matching
its format.

For example, the following input would be passed untouched by an HTML
Writer::

    .. raw:: html

       <hr width=50 size=10>

A LaTeX Writer could insert the following raw content into its
output stream::

    .. raw:: latex

       \setlength{\parindent}{0pt}

Raw data can also be read from an external file, specified in a
directive option.  In this case, the content block must be empty.  For
example::

    .. raw:: html
       :file: inclusion.html

The following options are recognized:

``file`` : string (newlines removed)
    The local filesystem path of a raw data file to be included.

``url`` : string (whitespace removed)
    An Internet URL reference to a raw data file to be included.

``encoding`` : name of text encoding
    The text encoding of the external raw data (file or URL).
    Defaults to the document's encoding (if specified).


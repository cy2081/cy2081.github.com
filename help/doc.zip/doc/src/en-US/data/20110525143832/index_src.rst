These options influence manual page output.

.. confval:: man_pages

   This value determines how to group the document tree into manual pages.  It
   must be a list of tuples ``(startdocname, name, description, authors,
   section)``, where the items are:

   * *startdocname*: document name that is the "root" of the manual page.  All
     documents referenced by it in TOC trees will be included in the manual file
     too.  (If you want one master manual page, use your :confval:`master_doc`
     here.)
   * *name*: name of the manual page.  This should be a short string without
     spaces or special characters.  It is used to determine the file name as
     well as the name of the manual page (in the NAME section).
   * *description*: description of the manual page.  This is used in the NAME
     section.
   * *authors*: A list of strings with authors, or a single string.  Can be
     an empty string or list if you do not want to automatically generate
     an AUTHORS section in the manual page.
   * *section*: The manual page section.  Used for the output file name as well
     as in the manual page header.

   .. versionadded:: 1.0


.. rubric:: Footnotes

.. [1] A note on available globbing syntax: you can use the standard shell
       constructs ``*``, ``?``, ``[...]`` and ``[!...]`` with the feature that
       these all don't match slashes.  A double star ``**`` can be used to match
       any sequence of characters *including* slashes.
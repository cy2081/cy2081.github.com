A hyperlink reference may directly embed a target URI inline, within
angle brackets ("<...>") as follows::

    See the `Python home page <http://www.python.org>`_ for info.

This is exactly equivalent to::

    See the `Python home page`_ for info.

    .. _Python home page: http://www.python.org

The bracketed URI must be preceded by whitespace and be the last text
before the end string.  With a single trailing underscore, the
reference is named and the same target URI may be referred to again.

With two trailing underscores, the reference and target are both
anonymous, and the target cannot be referred to again.  These are
"one-off" hyperlinks.  For example::

    `RFC 2396 <http://www.rfc-editor.org/rfc/rfc2396.txt>`__ and `RFC
    2732 <http://www.rfc-editor.org/rfc/rfc2732.txt>`__ together
    define the syntax of URIs.

Equivalent to::

    `RFC 2396`__ and `RFC 2732`__ together define the syntax of URIs.

    __ http://www.rfc-editor.org/rfc/rfc2396.txt
    __ http://www.rfc-editor.org/rfc/rfc2732.txt

If reference text happens to end with angle-bracketed text that is
*not* a URI, the open-angle-bracket needs to be backslash-escaped.
For example, here is a reference to a title describing a tag::

    See `HTML Element: \<a>`_ below.

The reference text may also be omitted, in which case the URI will be
duplicated for use as the reference text.  This is useful for relative
URIs where the address or file name is also the desired reference
text::

    See `<a_named_relative_link>`_ or `<an_anonymous_relative_link>`__
    for details.

.. CAUTION::

   This construct offers easy authoring and maintenance of hyperlinks
   at the expense of general readability.  Inline URIs, especially
   long ones, inevitably interrupt the natural flow of text.  For
   documents meant to be read in source form, the use of independent
   block-level `hyperlink targets`_ is **strongly recommended**.  The
   embedded URI construct is most suited to documents intended *only*
   to be read in processed form.
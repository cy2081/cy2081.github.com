:Directive Type: "highlights"
:Doctree Element: block_quote
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as the body of the block quote.

Highlights summarize the main points of a document or section, often
consisting of a list.

The "highlights" directive produces a "highlights"-class block quote.
See Epigraph_ above for an analogous example.

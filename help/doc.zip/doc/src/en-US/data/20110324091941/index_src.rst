*Baow* is a document editor that makes it easy to organize your plain text documents and web resources, and then create intelligent and beautiful web pages within `Firefox web browser`_ .

 |Du Wenshan| 

 :Author: Cyrus Baow
 :Contact: cy2081@baow.com
 :Version: |version|    (2012-05-07)
 :Download: `here <http://www.baow.com/help/baow-3.1.xpi>`_

 |screen| 

**Highlights** :

  * Tree based outline, help you organize internet resources and documents.
  * Save or bookmark web images, files or pages.
  * Multi level project management.
  * Full text search.
  * Write `Sphinx Markup`_  (`reStructuredText`_)  documents and generate web pages by `Sphinx`_ tools.

    * Easily configure and build documents.
    * Automatic create section headers level, no marker characters. 
    * Lots of quick menus, help you write and preview  `Sphinx Markup`_  documents.

  *  `Gvim`_  and  `Emacs`_  editor support.
  * Multi platform support, Windows, Linux, Mac etc.

Click menu   :menuselection:`New Document`  from the sidebar, and input title in bring up dialog, then input text in new opened tab editor, and click  :guilabel:`Save`  button finally.

You can add sub documents as sections by click pop up menu, or drag it to your target place.

.. tip:: A document can be contained by another document, this is document tree. Section mark characters is no longer needed.


You can select toctree style with sub documents in **Properties** dialog window by checking :guilabel:`Toctree`.

 |toctree|  
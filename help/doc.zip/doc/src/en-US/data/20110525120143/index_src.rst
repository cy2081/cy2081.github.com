There are some problems one commonly runs into while authoring reST documents:

* **Separation of inline markup:** As said above, inline markup spans must be
  separated from the surrounding text by non-word characters, you have to use a
  backslash-escaped space to get around that.  See `the reference
  <../20110525164311/index.html#inline-markup>`_
  for the details.

* **No nested inline markup:** Something like ``*see :func:`foo`*`` is not
  possible.


.. rubric:: Footnotes

.. [1] When the default domain contains a :rst:dir:`class` directive, this directive
       will be shadowed.  Therefore, Sphinx re-exports it as :rst:dir:`rst-class`.

To support cross-referencing to arbitrary locations in any document, you can set a reference label.

Open **Properties** window by right click pop up menu, select  **Reference**  tab :

 |set referencing label| 

Input your label text, and click :guilabel:`Copy`, and click :guilabel:`OK` button.

Paste text into your document where you want to refer to this label.
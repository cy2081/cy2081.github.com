Simple reference names are single words consisting of alphanumerics
plus isolated (no two adjacent) internal hyphens, underscores,
periods, colons and plus signs; no whitespace or other characters are
allowed.  Footnote labels (Footnotes_ & `Footnote References`_), citation
labels (Citations_ & `Citation References`_), `interpreted text`_ roles,
and some `hyperlink references`_ use the simple reference name syntax.

Reference names using punctuation or whose names are phrases (two or
more space-separated words) are called "phrase-references".
Phrase-references are expressed by enclosing the phrase in backquotes
and treating the backquoted text as a reference name::

    Want to learn about `my favorite programming language`_?

    .. _my favorite programming language: http://www.python.org

Simple reference names may also optionally use backquotes.

Reference names are whitespace-neutral and case-insensitive.  When
resolving reference names internally:

- whitespace is normalized (one or more spaces, horizontal or vertical
  tabs, newlines, carriage returns, or form feeds, are interpreted as
  a single space), and

- case is normalized (all alphabetic characters are converted to
  lowercase).

For example, the following `hyperlink references`_ are equivalent::

    - `A HYPERLINK`_
    - `a    hyperlink`_
    - `A
      Hyperlink`_

Hyperlinks_, footnotes_, and citations_ all share the same namespace
for reference names.  The labels of citations (simple reference names)
and manually-numbered footnotes (numbers) are entered into the same
database as other hyperlink names.  This means that a footnote
(defined as "``.. [1]``") which can be referred to by a footnote
reference (``[1]_``), can also be referred to by a plain hyperlink
reference (1_).  Of course, each type of reference (hyperlink,
footnote, citation) may be processed and rendered differently.  Some
care should be taken to avoid reference name conflicts.

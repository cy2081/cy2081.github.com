Indentation is used to indicate -- and is only significant in
indicating -- block quotes, definitions (in definition list items),
and local nested content:

- list item content (multi-line contents of list items, and multiple
  body elements within a list item, including nested lists),
- the content of literal blocks, and
- the content of explicit markup blocks.

Any text whose indentation is less than that of the current level
(i.e., unindented text or "dedents") ends the current level of
indentation.

Since all indentation is significant, the level of indentation must be
consistent.  For example, indentation is the sole markup indicator for
`block quotes`_::

    This is a top-level paragraph.

        This paragraph belongs to a first-level block quote.

        Paragraph 2 of the first-level block quote.

Multiple levels of indentation within a block quote will result in
more complex structures::

    This is a top-level paragraph.

        This paragraph belongs to a first-level block quote.

            This paragraph belongs to a second-level block quote.

    Another top-level paragraph.

            This paragraph belongs to a second-level block quote.

        This paragraph belongs to a first-level block quote.  The
        second-level block quote above is inside this first-level
        block quote.

When a paragraph or other construct consists of more than one line of
text, the lines must be left-aligned::

    This is a paragraph.  The lines of
    this paragraph are aligned at the left.

        This paragraph has problems.  The
    lines are not left-aligned.  In addition
      to potential misinterpretation, warning
        and/or error messages will be generated
      by the parser.

Several constructs begin with a marker, and the body of the construct
must be indented relative to the marker.  For constructs using simple
markers (`bullet lists`_, `enumerated lists`_, footnotes_, citations_,
`hyperlink targets`_, directives_, and comments_), the level of
indentation of the body is determined by the position of the first
line of text, which begins on the same line as the marker.  For
example, bullet list bodies must be indented by at least two columns
relative to the left edge of the bullet::

    - This is the first line of a bullet list
      item's paragraph.  All lines must align
      relative to the first line.  [1]_

          This indented paragraph is interpreted
          as a block quote.

    Because it is not sufficiently indented,
    this paragraph does not belong to the list
    item.

    .. [1] Here's a footnote.  The second line is aligned
       with the beginning of the footnote label.  The ".."
       marker is what determines the indentation.

For constructs using complex markers (`field lists`_ and `option
lists`_), where the marker may contain arbitrary text, the indentation
of the first line *after* the marker determines the left edge of the
body.  For example, field lists may have very long markers (containing
the field names)::

    :Hello: This field has a short field name, so aligning the field
            body with the first line is feasible.

    :Number-of-African-swallows-required-to-carry-a-coconut: It would
        be very difficult to align the field body with the left edge
        of the first line.  It may even be preferable not to begin the
        body on the same line as the marker.

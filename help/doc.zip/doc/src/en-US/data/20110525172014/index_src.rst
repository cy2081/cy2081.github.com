Doctree element: citation_reference.

Start-string = "[", end-string = "]_".

Each citation reference consists of a square-bracketed label followed
by a trailing underscore.  Citation labels are simple `reference
names`_ (case-insensitive single words, consisting of alphanumerics
plus internal hyphens, underscores, and periods; no whitespace).

For example::

    Here is a citation reference: [CIT2002]_.

See Citations_ for the citation itself.

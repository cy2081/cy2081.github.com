:Directive Type: "list-table"
:Doctree Element: table
:Directive Arguments: 1, optional (table title).
:Directive Options: Possible.
:Directive Content: A uniform two-level bullet list.

(New in Docutils 0.3.8.  This is an initial implementation; `further
ideas`__ may be implemented in the future.)

__ http://docutils.sourceforge.net/docs/dev/rst/alternatives.html#list-driven-tables

The "list-table" directive is used to create a table from data in a
uniform two-level bullet list.  "Uniform" means that each sublist
(second-level list) must contain the same number of list items.

Example::

    .. list-table:: Frozen Delights!
       :widths: 15 10 30
       :header-rows: 1

       * - Treat
         - Quantity
         - Description
       * - Albatross
         - 2.99
         - On a stick!
       * - Crunchy Frog
         - 1.49
         - If we took the bones out, it wouldn't be
           crunchy, now would it?
       * - Gannet Ripple
         - 1.99
         - On a stick!

The following options are recognized:

``class`` : text
    Set a "classes" attribute value on the table element.  See the
    class_ directive below.

``widths`` : integer [integer...]
    A comma- or space-separated list of relative column widths.  The
    default is equal-width columns (100%/#columns).

``header-rows`` : integer
    The number of rows of list data to use in the table header.
    Defaults to 0.

``stub-columns`` : integer
    The number of table columns to use as stubs (row titles, on the
    left).  Defaults to 0.


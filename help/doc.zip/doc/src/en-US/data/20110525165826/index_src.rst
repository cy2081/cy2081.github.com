Doctree elements: enumerated_list, list_item.

Enumerated lists (a.k.a. "ordered" lists) are similar to bullet lists,
but use enumerators instead of bullets.  An enumerator consists of an
enumeration sequence member and formatting, followed by whitespace.
The following enumeration sequences are recognized:

- arabic numerals: 1, 2, 3, ... (no upper limit).
- uppercase alphabet characters: A, B, C, ..., Z.
- lower-case alphabet characters: a, b, c, ..., z.
- uppercase Roman numerals: I, II, III, IV, ..., MMMMCMXCIX (4999).
- lowercase Roman numerals: i, ii, iii, iv, ..., mmmmcmxcix (4999).

In addition, the auto-enumerator, "#", may be used to automatically
enumerate a list.  Auto-enumerated lists may begin with explicit
enumeration, which sets the sequence.  Fully auto-enumerated lists use
arabic numerals and begin with 1.  (Auto-enumerated lists are new in
Docutils 0.3.8.)

The following formatting types are recognized:

- suffixed with a period: "1.", "A.", "a.", "I.", "i.".
- surrounded by parentheses: "(1)", "(A)", "(a)", "(I)", "(i)".
- suffixed with a right-parenthesis: "1)", "A)", "a)", "I)", "i)".

While parsing an enumerated list, a new list will be started whenever:

- An enumerator is encountered which does not have the same format and
  sequence type as the current list (e.g. "1.", "(a)" produces two
  separate lists).

- The enumerators are not in sequence (e.g., "1.", "3." produces two
  separate lists).

It is recommended that the enumerator of the first list item be
ordinal-1 ("1", "A", "a", "I", or "i").  Although other start-values
will be recognized, they may not be supported by the output format.  A
level-1 [info] system message will be generated for any list beginning
with a non-ordinal-1 enumerator.

Lists using Roman numerals must begin with "I"/"i" or a
multi-character value, such as "II" or "XV".  Any other
single-character Roman numeral ("V", "X", "L", "C", "D", "M") will be
interpreted as a letter of the alphabet, not as a Roman numeral.
Likewise, lists using letters of the alphabet may not begin with
"I"/"i", since these are recognized as Roman numeral 1.

The second line of each enumerated list item is checked for validity.
This is to prevent ordinary paragraphs from being mistakenly
interpreted as list items, when they happen to begin with text
identical to enumerators.  For example, this text is parsed as an
ordinary paragraph::

    A. Einstein was a really
    smart dude.

However, ambiguity cannot be avoided if the paragraph consists of only
one line.  This text is parsed as an enumerated list item::

    A. Einstein was a really smart dude.

If a single-line paragraph begins with text identical to an enumerator
("A.", "1.", "(b)", "I)", etc.), the first character will have to be
escaped in order to have the line parsed as an ordinary paragraph::

    \A. Einstein was a really smart dude.

Examples of nested enumerated lists::

    1. Item 1 initial text.

       a) Item 1a.
       b) Item 1b.

    2. a) Item 2a.
       b) Item 2b.

Example syntax diagram::

    +-------+----------------------+
    | "1. " | list item            |
    +-------| (body elements)+     |
            +----------------------+


Doctree elements: field_list, field, field_name, field_body.

Field lists are used as part of an extension syntax, such as options
for directives_, or database-like records meant for further
processing.  They may also be used for two-column table-like
structures resembling database records (label & data pairs).
Applications of reStructuredText may recognize field names and
transform fields or field bodies in certain contexts.  For examples,
see `Bibliographic Fields`_ below, or the "image_" and "meta_"
directives in `reStructuredText Directives`_.

Field lists are mappings from field names to field bodies, modeled on
RFC822_ headers.  A field name may consist of any characters, but
colons (":") inside of field names must be escaped with a backslash.
Inline markup is parsed in field names.  Field names are
case-insensitive when further processed or transformed.  The field
name, along with a single colon prefix and suffix, together form the
field marker.  The field marker is followed by whitespace and the
field body.  The field body may contain multiple body elements,
indented relative to the field marker.  The first line after the field
name marker determines the indentation of the field body.  For
example::

    :Date: 2001-08-16
    :Version: 1
    :Authors: - Me
              - Myself
              - I
    :Indentation: Since the field marker may be quite long, the second
       and subsequent lines of the field body do not have to line up
       with the first line, but they must be indented relative to the
       field name marker, and they must line up with each other.
    :Parameter i: integer

The interpretation of individual words in a multi-word field name is
up to the application.  The application may specify a syntax for the
field name.  For example, second and subsequent words may be treated
as "arguments", quoted phrases may be treated as a single argument,
and direct support for the "name=value" syntax may be added.

Standard RFC822_ headers cannot be used for this construct because
they are ambiguous.  A word followed by a colon at the beginning of a
line is common in written text.  However, in well-defined contexts
such as when a field list invariably occurs at the beginning of a
document (PEPs and email messages), standard RFC822 headers could be
used.

Syntax diagram (simplified)::

    +--------------------+----------------------+
    | ":" field name ":" | field body           |
    +-------+------------+                      |
            | (body elements)+                  |
            +-----------------------------------+

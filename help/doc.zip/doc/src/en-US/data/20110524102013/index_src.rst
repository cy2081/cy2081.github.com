You can add source files from local directory, and edit code.

Click menu   :menuselection:`New Source File` , and select your local file, like C++, Java, Python, PHP files.
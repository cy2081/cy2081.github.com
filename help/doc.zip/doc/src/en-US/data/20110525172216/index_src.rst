The following length units are supported by the reStructuredText
parser:

* em (ems, the height of the element's font)
* ex (x-height, the height of the letter "x")
* px (pixels, relative to the canvas resolution)
* in (inches; 1in=2.54cm)
* cm (centimeters; 1cm=10mm)
* mm (millimeters)
* pt (points; 1pt=1/72in)
* pc (picas; 1pc=12pt)

This set corresponds to the `length units in CSS`_.

(List and explanations taken from
http://www.htmlhelp.com/reference/css/units.html#length.)

The following are all valid length values: "1.5em", "20 mm", ".5in".

Length values without unit are completed with a writer-dependent
default (e.g. px with `html4css1`, pt with `latex2e`). See the writer
specific documentation in the `user doc`__ for details.

.. _length units in CSS:
   http://www.w3.org/TR/CSS2/syndata.html#length-units

__ ../../user/
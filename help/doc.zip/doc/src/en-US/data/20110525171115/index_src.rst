Doctree element: target.

These are also called _`explicit hyperlink targets`, to differentiate
them from `implicit hyperlink targets`_ defined below.

Hyperlink targets identify a location within or outside of a document,
which may be linked to by `hyperlink references`_.

Hyperlink targets may be named or anonymous.  Named hyperlink targets
consist of an explicit markup start (".. "), an underscore, the
reference name (no trailing underscore), a colon, whitespace, and a
link block::

    .. _hyperlink-name: link-block

Reference names are whitespace-neutral and case-insensitive.  See
`Reference Names`_ for details and examples.

Anonymous hyperlink targets consist of an explicit markup start
(".. "), two underscores, a colon, whitespace, and a link block; there
is no reference name::

    .. __: anonymous-hyperlink-target-link-block

An alternate syntax for anonymous hyperlinks consists of two
underscores, a space, and a link block::

    __ anonymous-hyperlink-target-link-block

See `Anonymous Hyperlinks`_ below.

There are three types of hyperlink targets: internal, external, and
indirect.

1. _`Internal hyperlink targets` have empty link blocks.  They provide
   an end point allowing a hyperlink to connect one place to another
   within a document.  An internal hyperlink target points to the
   element following the target.  For example::

       Clicking on this internal hyperlink will take us to the target_
       below.

       .. _target:

       The hyperlink target above points to this paragraph.

   Internal hyperlink targets may be "chained".  Multiple adjacent
   internal hyperlink targets all point to the same element::

       .. _target1:
       .. _target2:

       The targets "target1" and "target2" are synonyms; they both
       point to this paragraph.

   If the element "pointed to" is an external hyperlink target (with a
   URI in its link block; see #2 below) the URI from the external
   hyperlink target is propagated to the internal hyperlink targets;
   they will all "point to" the same URI.  There is no need to
   duplicate a URI.  For example, all three of the following hyperlink
   targets refer to the same URI::

       .. _Python DOC-SIG mailing list archive:
       .. _archive:
       .. _Doc-SIG: http://mail.python.org/pipermail/doc-sig/

   An inline form of internal hyperlink target is available; see
   `Inline Internal Targets`_.

2. _`External hyperlink targets` have an absolute or relative URI or
   email address in their link blocks.  For example, take the
   following input::

       See the Python_ home page for info.

       `Write to me`_ with your questions.

       .. _Python: http://www.python.org
       .. _Write to me: jdoe@example.com

   After processing into HTML, the hyperlinks might be expressed as::

       See the <a href="http://www.python.org">Python</a> home page
       for info.

       <a href="mailto:jdoe@example.com">Write to me</a> with your
       questions.

   An external hyperlink's URI may begin on the same line as the
   explicit markup start and target name, or it may begin in an
   indented text block immediately following, with no intervening
   blank lines.  If there are multiple lines in the link block, they
   are concatenated.  Any whitespace is removed (whitespace is
   permitted to allow for line wrapping).  The following external
   hyperlink targets are equivalent::

       .. _one-liner: http://docutils.sourceforge.net/rst.html

       .. _starts-on-this-line: http://
          docutils.sourceforge.net/rst.html

       .. _entirely-below:
          http://docutils.
          sourceforge.net/rst.html

   If an external hyperlink target's URI contains an underscore as its
   last character, it must be escaped to avoid being mistaken for an
   indirect hyperlink target::

       This link_ refers to a file called ``underscore_``.

       .. _link: underscore\_

   It is possible (although not generally recommended) to include URIs
   directly within hyperlink references.  See `Embedded URIs`_ below.

3. _`Indirect hyperlink targets` have a hyperlink reference in their
   link blocks.  In the following example, target "one" indirectly
   references whatever target "two" references, and target "two"
   references target "three", an internal hyperlink target.  In
   effect, all three reference the same thing::

       .. _one: two_
       .. _two: three_
       .. _three:

   Just as with `hyperlink references`_ anywhere else in a document,
   if a phrase-reference is used in the link block it must be enclosed
   in backquotes.  As with `external hyperlink targets`_, the link
   block of an indirect hyperlink target may begin on the same line as
   the explicit markup start or the next line.  It may also be split
   over multiple lines, in which case the lines are joined with
   whitespace before being normalized.

   For example, the following indirect hyperlink targets are
   equivalent::

       .. _one-liner: `A HYPERLINK`_
       .. _entirely-below:
          `a    hyperlink`_
       .. _split: `A
          Hyperlink`_

If the reference name contains any colons, either:

- the phrase must be enclosed in backquotes::

      .. _`FAQTS: Computers: Programming: Languages: Python`:
         http://python.faqts.com/

- or the colon(s) must be backslash-escaped in the link target::

      .. _Chapter One\: "Tadpole Days":

      It's not easy being green...

See `Implicit Hyperlink Targets`_ below for the resolution of
duplicate reference names.

Syntax diagram::

    +-------+----------------------+
    | ".. " | "_" name ":" link    |
    +-------+ block                |
            |                      |
            +----------------------+


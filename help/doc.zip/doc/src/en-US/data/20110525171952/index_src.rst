Doctree element: footnote_reference.

Start-string = "[", end-string = "]_".

Each footnote reference consists of a square-bracketed label followed
by a trailing underscore.  Footnote labels are one of:

- one or more digits (i.e., a number),

- a single "#" (denoting `auto-numbered footnotes`_),

- a "#" followed by a simple reference name (an `autonumber label`_),
  or

- a single "*" (denoting `auto-symbol footnotes`_).

For example::

    Please RTFM [1]_.

    .. [1] Read The Fine Manual


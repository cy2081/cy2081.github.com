An explicit markup block is a text block:

- whose first line begins with ".." followed by whitespace (the
  "explicit markup start"),
- whose second and subsequent lines (if any) are indented relative to
  the first, and
- which ends before an unindented line.

Explicit markup blocks are analogous to bullet list items, with ".."
as the bullet.  The text on the lines immediately after the explicit
markup start determines the indentation of the block body.  The
maximum common indentation is always removed from the second and
subsequent lines of the block body.  Therefore if the first construct
fits in one line, and the indentation of the first and second
constructs should differ, the first construct should not begin on the
same line as the explicit markup start.

Blank lines are required between explicit markup blocks and other
elements, but are optional between explicit markup blocks where
unambiguous.

The explicit markup syntax is used for footnotes, citations, hyperlink
targets, directives, substitution definitions, and comments.
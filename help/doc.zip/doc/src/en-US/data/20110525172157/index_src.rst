(New in Docutils 0.3.10.)

All measures consist of a positive floating point number in standard
(non-scientific) notation and a unit, possibly separated by one or
more spaces.

Units are only supported where explicitly mentioned in the reference
manuals.

Summary text will be inserted into document, and displayed in sequence.

Click menu   :menuselection:`New Summary` from the sidebar, and input title dialog, then input text in new opened tab editor, and click  :guilabel:`Save`  button.



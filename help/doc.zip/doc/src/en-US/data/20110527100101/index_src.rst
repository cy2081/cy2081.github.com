After you have added a image. You can copy its ReST text, and paste into your document where you want to display image.

 |copy image rst| 

Select "Image Replace" from pop up menu.
Quoted literal blocks are unindented contiguous blocks of text where
each line begins with the same non-alphanumeric printable 7-bit ASCII
character [#]_.  A blank line ends a quoted literal block.  The
quoting characters are preserved in the processed document.

.. [#]
   The following are all valid quoting characters::

       ! " # $ % & ' ( ) * + , - . / : ; < = > ? @ [ \ ] ^ _ ` { | } ~

   Note that these are the same characters as are valid for title
   adornment of sections_.

Possible uses include literate programming in Haskell and email
quoting::

    John Doe wrote::

    >> Great idea!
    >
    > Why didn't I think of that?

    You just did!  ;-)

Syntax diagram::

    +------------------------------+
    | paragraph                    |
    | (ends with "::")             |
    +------------------------------+
    +------------------------------+
    | ">" per-line-quoted          |
    | ">" contiguous literal block |
    +------------------------------+


The character set universally available to plaintext documents, 7-bit
ASCII, is limited.  No matter what characters are used for markup,
they will already have multiple meanings in written text.  Therefore
markup characters *will* sometimes appear in text **without being
intended as markup**.  Any serious markup system requires an escaping
mechanism to override the default meaning of the characters used for
the markup.  In reStructuredText we use the backslash, commonly used
as an escaping character in other domains.

A backslash followed by any character (except whitespace characters)
escapes that character.  The escaped character represents the
character itself, and is prevented from playing a role in any markup
interpretation.  The backslash is removed from the output.  A literal
backslash is represented by two backslashes in a row (the first
backslash "escapes" the second, preventing it being interpreted in an
"escaping" role).

Backslash-escaped whitespace characters are removed from the document.
This allows for character-level `inline markup`_.

There are two contexts in which backslashes have no special meaning:
literal blocks and inline literals.  In these contexts, a single
backslash represents a literal backslash, without having to double up.

Please note that the reStructuredText specification and parser do not
address the issue of the representation or extraction of text input
(how and in what form the text actually *reaches* the parser).
Backslashes and other characters may serve a character-escaping
purpose in certain contexts and must be dealt with appropriately.  For
example, Python uses backslashes in strings to escape certain
characters, but not others.  The simplest solution when backslashes
appear in Python docstrings is to use raw docstrings::

    r"""This is a raw docstring.  Backslashes (\) are not touched."""


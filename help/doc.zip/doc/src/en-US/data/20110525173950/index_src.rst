:Directive Type: "pull-quote"
:Doctree Element: block_quote
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as the body of the block quote.

A pull-quote is a small selection of text "pulled out and quoted",
typically in a larger typeface.  Pull-quotes are used to attract
attention, especially in long articles.

The "pull-quote" directive produces a "pull-quote"-class block quote.
See Epigraph_ above for an analogous example.

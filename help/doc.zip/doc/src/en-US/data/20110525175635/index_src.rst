:Directive Type: "class"
:Doctree Element: pending
:Directive Arguments: One or more, required (class names / attribute
                      values).
:Directive Options: None.
:Directive Content: Optional.  If present, it is interpreted as body
                    elements.

The "class" directive sets the "classes" attribute value on its content
or on the first immediately following non-comment element [#]_.  For
details of the "classes" attribute, see `its entry`__ in `The Docutils
Document Tree`_.

The directive argument consists of one or more space-separated class
names. The names are transformed to conform to the regular expression
``[a-z](-?[a-z0-9]+)*`` by converting

* alphabetic characters to lowercase,
* accented characters to the base character,
* non-alphanumeric characters to hyphens,
* consecutive hyphens into one hyphen.

For example "Rot-Gelb.Blau Grün:+2008" becomes "rot-gelb-blau grun-2008".
(For the rationale_, see below.)

__ http://docutils.sourceforge.net/docs/ref/doctree.html#classes

Examples::

    .. class:: special

    This is a "special" paragraph.

    .. class:: exceptional remarkable

    An Exceptional Section
    ======================

    This is an ordinary paragraph.

    .. class:: multiple

       First paragraph.

       Second paragraph.

The text above is parsed and transformed into this doctree fragment::

    <paragraph classes="special">
        This is a "special" paragraph.
    <section classes="exceptional remarkable">
        <title>
            An Exceptional Section
        <paragraph>
            This is an ordinary paragraph.
        <paragraph classes="multiple">
            First paragraph.
        <paragraph classes="multiple">
            Second paragraph.

.. [#] To set a "classes" attribute value on a block quote, the
   "class" directive must be followed by an empty comment::

       .. class:: highlights
       ..

           Block quote text.

   An empty comment is required to terminate the directive to allow
   the indented text to be parsed as a block quote.  Without the empty
   comment, the indented text would be interpreted as the "class"
   directive's content, and the classes would be applied to each
   element (paragraph, in this case) individually, instead of to the
   block quote as a whole.

.. _rationale:

.. topic:: Rationale for "classes" Attribute Value Conversion


    Docutils identifiers are converted to conform to the regular
    expression ``[a-z](-?[a-z0-9]+)*``.  For HTML + CSS compatibility,
    identifiers (the "classes" and "id" attributes) should have no
    underscores, colons, or periods.  Hyphens may be used.

    - The `HTML 4.01 spec`_ defines identifiers based on SGML tokens:

          ID and NAME tokens must begin with a letter ([A-Za-z]) and
          may be followed by any number of letters, digits ([0-9]),
          hyphens ("-"), underscores ("_"), colons (":"), and periods
          (".").

    - The `CSS1 spec`_ defines identifiers based on the "name" token
      ("flex" tokenizer notation below; "latin1" and "escape" 8-bit
      characters have been replaced with XML entities)::

          unicode     \\[0-9a-f]{1,4}
          latin1      [&iexcl;-&yuml;]
          escape      {unicode}|\\[ -~&iexcl;-&yuml;]
          nmchar      [-A-Za-z0-9]|{latin1}|{escape}
          name        {nmchar}+

    The CSS rule does not include underscores ("_"), colons (":"), or
    periods ("."), therefore "classes" and "id" attributes should not
    contain these characters.  Combined with HTML's requirements (the
    first character must be a letter; no "unicode", "latin1", or
    "escape" characters), this results in the regular expression
    ``[A-Za-z][-A-Za-z0-9]*``. Docutils adds a normalisation by
    downcasing and merge of consecutive hyphens.

    .. _HTML 4.01 spec: http://www.w3.org/TR/html401/
    .. _CSS1 spec: http://www.w3.org/TR/REC-CSS1


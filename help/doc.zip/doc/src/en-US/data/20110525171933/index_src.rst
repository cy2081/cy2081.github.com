Doctree element: target.

Start-string = "_`", end-string = "`".

Inline internal targets are the equivalent of explicit `internal
hyperlink targets`_, but may appear within running text.  The syntax
begins with an underscore and a backquote, is followed by a hyperlink
name or phrase, and ends with a backquote.  Inline internal targets
may not be anonymous.

For example, the following paragraph contains a hyperlink target named
"Norwegian Blue"::

    Oh yes, the _`Norwegian Blue`.  What's, um, what's wrong with it?

See `Implicit Hyperlink Targets`_ for the resolution of duplicate
reference names.
Doctree element: comment.

Arbitrary indented text may follow the explicit markup start and will
be processed as a comment element.  No further processing is done on
the comment block text; a comment contains a single "text blob".
Depending on the output formatter, comments may be removed from the
processed output.  The only restriction on comments is that they not
use the same syntax as any of the other explicit markup constructs:
substitution definitions, directives, footnotes, citations, or
hyperlink targets.  To ensure that none of the other explicit markup
constructs is recognized, leave the ".." on a line by itself::

    .. This is a comment
    ..
       _so: is this!
    ..
       [and] this!
    ..
       this:: too!
    ..
       |even| this:: !

.. _empty comments:

An explicit markup start followed by a blank line and nothing else
(apart from whitespace) is an "_`empty comment`".  It serves to
terminate a preceding construct, and does **not** consume any indented
text following.  To have a block quote follow a list or any indented
construct, insert an unindented empty comment in-between.

Syntax diagram::

    +-------+----------------------+
    | ".. " | comment              |
    +-------+ block                |
            |                      |
            +----------------------+


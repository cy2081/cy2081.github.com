Click the button |project| :

 |project manage| 



:Directive Type: "include"
:Doctree Elements: depend on data being included
:Directive Arguments: One, required (path to the file to include).
:Directive Options: Possible.
:Directive Content: None.

.. WARNING::

   The "include" directive represents a potential security hole.  It
   can be disabled with the "file_insertion_enabled_" runtime setting.

   .. _file_insertion_enabled: http://docutils.sourceforge.net/docs/user/config.html#file-insertion-enabled

The "include" directive reads a reStructuredText-formatted text file
and parses it in the current document's context at the point of the
directive.  The directive argument is the path to the file to be
included, relative to the document containing the directive.  For
example::

    This first example will be parsed at the document level, and can
    thus contain any construct, including section headers.

    .. include:: inclusion.txt

    Back in the main document.

        This second example will be parsed in a block quote context.
        Therefore it may only contain body elements.  It may not
        contain section headers.

        .. include:: inclusion.txt

If an included document fragment contains section structure, the title
adornments must match those of the master document.

Standard data files intended for inclusion in reStructuredText
documents are distributed with the Docutils source code, located in
the "docutils" package in the ``docutils/parsers/rst/include``
directory.  To access these files, use the special syntax for standard
"include" data files, angle brackets around the file name::

    .. include:: <isonum.txt>

The current set of standard "include" data files consists of sets of
substitution definitions.  See `reStructuredText Standard Substitution
Definition Sets`__ for details of the available standard data files.

__ http://docutils.sourceforge.net/docs/ref/rst/substitutions.html

The following options are recognized:

``start-line`` : integer
    Only the content starting from this line will be included.
    (As usual in Python, the first line has index 0 and negative values
    count from the end.)

``end-line`` : integer
    Only the content up to (but excluding) this line will be included.

``start-after`` : text to find in the external data file
    Only the content after the first occurrence of the specified text
    will be included.

``end-before`` : text to find in the external data file
    Only the content before the first occurrence of the specified text
    (but after any ``after`` text) will be included.

``literal`` : flag (empty)
    The entire included text is inserted into the document as a single
    literal block (useful for program listings).

``encoding`` : name of text encoding
    The text encoding of the external data file.  Defaults to the
    document's input_encoding_.

    .. _input_encoding: http://docutils.sourceforge.net/docs/user/config.html#input-encoding

``tab-width`` :  integer
    Number of spaces for hard tab expansion.
    A negative value prevents expansion of hard tabs. Defaults to the
    tab_width_ configuration setting.

    .. _tab_width: http://docutils.sourceforge.net/docs/user/config.html#tab-width


Combining ``start/end-line`` and ``start-after/end-before`` is possible. The
text markers will be searched in the specified lines (further limiting the
included content).
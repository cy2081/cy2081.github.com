Doctree elements: docinfo, author, authors, organization, contact,
version, status, date, copyright, field, topic.

When a field list is the first non-comment element in a document
(after the document title, if there is one), it may have its fields
transformed to document bibliographic data.  This bibliographic data
corresponds to the front matter of a book, such as the title page and
copyright page.

Certain registered field names (listed below) are recognized and
transformed to the corresponding doctree elements, most becoming child
elements of the "docinfo" element.  No ordering is required of these
fields, although they may be rearranged to fit the document structure,
as noted.  Unless otherwise indicated below, each of the bibliographic
elements' field bodies may contain a single paragraph only.  Field
bodies may be checked for `RCS keywords`_ and cleaned up.  Any
unrecognized fields will remain as generic fields in the docinfo
element.

The registered bibliographic field names and their corresponding
doctree elements are as follows:

- Field name "Author": author element.
- "Authors": authors.
- "Organization": organization.
- "Contact": contact.
- "Address": address.
- "Version": version.
- "Status": status.
- "Date": date.
- "Copyright": copyright.
- "Dedication": topic.
- "Abstract": topic.

The "Authors" field may contain either: a single paragraph consisting
of a list of authors, separated by ";" or ","; or a bullet list whose
elements each contain a single paragraph per author.  ";" is checked
first, so "Doe, Jane; Doe, John" will work.  In some languages
(e.g. Swedish), there is no singular/plural distinction between
"Author" and "Authors", so only an "Authors" field is provided, and a
single name is interpreted as an "Author".  If a single name contains
a comma, end it with a semicolon to disambiguate: ":Authors: Doe,
Jane;".

The "Address" field is for a multi-line surface mailing address.
Newlines and whitespace will be preserved.

The "Dedication" and "Abstract" fields may contain arbitrary body
elements.  Only one of each is allowed.  They become topic elements
with "Dedication" or "Abstract" titles (or language equivalents)
immediately following the docinfo element.

This field-name-to-element mapping can be replaced for other
languages.  See the `DocInfo transform`_ implementation documentation
for details.

Unregistered/generic fields may contain one or more paragraphs or
arbitrary body elements.
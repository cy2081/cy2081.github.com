:Directive Type: "admonition"
:Doctree Elements: admonition, title
:Directive Arguments: One, required (admonition title)
:Directive Options: Possible.
:Directive Content: Interpreted as body elements.

This is a generic, titled admonition.  The title may be anything the
author desires.

The author-supplied title is also used as a "classes" attribute value
after being converted into a valid identifier form (down-cased;
non-alphanumeric characters converted to single hyphens; "admonition-"
prefixed).  For example, this admonition::

    .. admonition:: And, by the way...

       You can make up your own admonition too.

becomes the following document tree (pseudo-XML)::

    <document source="test data">
        <admonition classes="admonition-and-by-the-way">
            <title>
                And, by the way...
            <paragraph>
                You can make up your own admonition too.

The following option is recognized:

``class`` : text
    Override the computed "classes" attribute value.  See the class_
    directive below.

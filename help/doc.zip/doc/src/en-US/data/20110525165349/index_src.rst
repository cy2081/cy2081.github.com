Doctree element: document.

The top-level element of a parsed reStructuredText document is the
"document" element.  After initial parsing, the document element is a
simple container for a document fragment, consisting of `body
elements`_, transitions_, and sections_, but lacking a document title
or other bibliographic elements.  The code that calls the parser may
choose to run one or more optional post-parse transforms_,
rearranging the document fragment into a complete document with a
title and possibly other metadata elements (author, date, etc.; see
`Bibliographic Fields`_).

Specifically, there is no way to indicate a document title and
subtitle explicitly in reStructuredText.  Instead, a lone top-level
section title (see Sections_ below) can be treated as the document
title.  Similarly, a lone second-level section title immediately after
the "document title" can become the document subtitle.  The rest of
the sections are then lifted up a level or two.  See the `DocTitle
transform`_ for details.

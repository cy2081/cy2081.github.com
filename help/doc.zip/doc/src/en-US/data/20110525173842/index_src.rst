:Directive Type: "rubric"
:Doctree Element: rubric
:Directive Arguments: 1, required (rubric text).
:Directive Options: Possible.
:Directive Content: None.

..

     rubric n. 1. a title, heading, or the like, in a manuscript,
     book, statute, etc., written or printed in red or otherwise
     distinguished from the rest of the text. ...

     -- Random House Webster's College Dictionary, 1991

The "rubric" directive inserts a "rubric" element into the document
tree.  A rubric is like an informal heading that doesn't correspond to
the document's structure.

The following option is recognized:

``class`` : text
    Set a "classes" attribute value on the rubric element.  See the
    class_ directive below.

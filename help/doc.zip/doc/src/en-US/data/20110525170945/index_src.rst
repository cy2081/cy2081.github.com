An asterisk ("*") may be used for footnote labels to request automatic
symbol generation for footnotes and footnote references.  The asterisk
may be the only character in the label.  For example::

    Here is a symbolic footnote reference: [*]_.

    .. [*] This is the footnote.

A transform will insert symbols as labels into corresponding footnotes
and footnote references.  The number of references must be equal to
the number of footnotes.  One symbol footnote cannot have multiple
references.

The standard Docutils system uses the following symbols for footnote
marks [#]_:

- asterisk/star ("*")
- dagger (HTML character entity "&dagger;", Unicode U+02020)
- double dagger ("&Dagger;"/U+02021)
- section mark ("&sect;"/U+000A7)
- pilcrow or paragraph mark ("&para;"/U+000B6)
- number sign ("#")
- spade suit ("&spades;"/U+02660)
- heart suit ("&hearts;"/U+02665)
- diamond suit ("&diams;"/U+02666)
- club suit ("&clubs;"/U+02663)

.. [#] This list was inspired by the list of symbols for "Note
   Reference Marks" in The Chicago Manual of Style, 14th edition,
   section 12.51.  "Parallels" ("||") were given in CMoS instead of
   the pilcrow.  The last four symbols (the card suits) were added
   arbitrarily.

If more than ten symbols are required, the same sequence will be
reused, doubled and then tripled, and so on ("**" etc.).

.. Note:: When using auto-symbol footnotes, the choice of output
   encoding is important.  Many of the symbols used are not encodable
   in certain common text encodings such as Latin-1 (ISO 8859-1).  The
   use of UTF-8 for the output encoding is recommended.  An
   alternative for HTML and XML output is to use the
   "xmlcharrefreplace" `output encoding error handler`__.

__ ../../user/config.html#output-encoding-error-handler
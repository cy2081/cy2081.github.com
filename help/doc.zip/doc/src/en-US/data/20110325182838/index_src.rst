1. Install  `Firefox web browser`_ .
2. Install  `baow`_  and restart Firefox.

If you want to generate web pages with  `Sphinx`_ tools:

3. Install  `Python Programming Language`_ .
4. Install  `Python Package: Sphinx`_ , or install it with::
     
        easy_install -U Sphinx

     
   You can get ``easy_install`` from `Python Package Index : setuptools`_ 

   Finally, you should find sphinx command like this::

         C:\Python27\Scripts\sphinx-build.exe
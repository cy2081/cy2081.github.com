.. highlight:: rest

Sphinx uses interpreted text roles to insert semantic markup into documents.
They are written as ``:rolename:`content```.

.. note::

   The default role (```content```) has no special meaning by default.  You are
   free to use it for anything you like, e.g. variable names; use the
   :confval:`default_role` config value to set it to a known role.

See :ref:`domains` for roles added by domains.
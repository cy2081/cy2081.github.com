Sphinx adds a lot of new directives and interpreted text roles to `standard reST
markup`_.  This section contains the reference material for these facilities.
You can use these *shortcut keys* if it's enabled in Options.

Text edit mode:


.. versionchanged:: 2.8
   removed ``Ctrl - y`` and ``Ctrl - e``.

* Ctrl - y : launch Gvim editor.
* Ctrl - e : launch Emacs editor.
* F5 : input date string.
* F6 : save text.


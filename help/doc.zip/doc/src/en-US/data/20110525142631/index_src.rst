The sphinx-contrib_ repository contains more domains available as extensions;
currently a Ruby and an Erlang domain.


.. _sphinx-contrib: http://bitbucket.org/birkenfeld/sphinx-contrib/

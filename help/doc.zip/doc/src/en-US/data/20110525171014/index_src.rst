Manual and automatic footnote numbering may both be used within a
single document, although the results may not be expected.  Manual
numbering takes priority.  Only unused footnote numbers are assigned
to auto-numbered footnotes.  The following example should be
illustrative::

    [2]_ will be "2" (manually numbered),
    [#]_ will be "3" (anonymous auto-numbered), and
    [#label]_ will be "1" (labeled auto-numbered).

    .. [2] This footnote is labeled manually, so its number is fixed.

    .. [#label] This autonumber-labeled footnote will be labeled "1".
       It is the first auto-numbered footnote and no other footnote
       with label "1" exists.  The order of the footnotes is used to
       determine numbering, not the order of the footnote references.

    .. [#] This footnote will be labeled "3".  It is the second
       auto-numbered footnote, but footnote label "2" is already used.
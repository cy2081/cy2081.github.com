.. highlightlang:: rest

This document describes the directives implemented in the reference
reStructuredText parser.

Directives have the following syntax::

    +-------+-------------------------------+
    | ".. " | directive type "::" directive |
    +-------+ block                         |
            |                               |
            +-------------------------------+

Directives begin with an explicit markup start (two periods and a
space), followed by the directive type and two colons (collectively,
the "directive marker").  The directive block begins immediately after
the directive marker, and includes all subsequent indented lines.  The
directive block is divided into arguments, options (a field list), and
content (in that order), any of which may appear.  See the Directives_
section in the `reStructuredText Markup Specification`_ for syntax
details.

Descriptions below list "doctree elements" (document tree element
names; XML DTD generic identifiers) corresponding to individual
directives.  For details on the hierarchy of elements, please see `The
Docutils Document Tree`_ and the `Docutils Generic DTD`_ XML document
type definition.  For directive implementation details, see `Creating
reStructuredText Directives`_.

.. _Directives: ../20110525164311/index.html#directives
.. _reStructuredText Markup Specification: ../20110525164311/index.html
.. _The Docutils Document Tree: http://docutils.sourceforge.net/docs/ref/doctree.html
.. _Docutils Generic DTD: http://docutils.sourceforge.net/docs/ref/docutils.dtd
.. _Creating reStructuredText Directives:
   http://docutils.sourceforge.net/docs/howto/rst-directives.html


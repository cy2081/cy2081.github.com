Doctree elements: definition_list, definition_list_item, term,
classifier, definition.

Each definition list item contains a term, optional classifiers, and a
definition.  A term is a simple one-line word or phrase.  Optional
classifiers may follow the term on the same line, each after an inline
" : " (space, colon, space).  A definition is a block indented
relative to the term, and may contain multiple paragraphs and other
body elements.  There may be no blank line between a term line and a
definition block (this distinguishes definition lists from `block
quotes`_).  Blank lines are required before the first and after the
last definition list item, but are optional in-between.  For example::

    term 1
        Definition 1.

    term 2
        Definition 2, paragraph 1.

        Definition 2, paragraph 2.

    term 3 : classifier
        Definition 3.

    term 4 : classifier one : classifier two
        Definition 4.

Inline markup is parsed in the term line before the classifier
delimiter (" : ") is recognized.  The delimiter will only be
recognized if it appears outside of any inline markup.

A definition list may be used in various ways, including:

- As a dictionary or glossary.  The term is the word itself, a
  classifier may be used to indicate the usage of the term (noun,
  verb, etc.), and the definition follows.

- To describe program variables.  The term is the variable name, a
  classifier may be used to indicate the type of the variable (string,
  integer, etc.), and the definition describes the variable's use in
  the program.  This usage of definition lists supports the classifier
  syntax of Grouch_, a system for describing and enforcing a Python
  object schema.

Syntax diagram::

    +----------------------------+
    | term [ " : " classifier ]* |
    +--+-------------------------+--+
       | definition                 |
       | (body elements)+           |
       +----------------------------+


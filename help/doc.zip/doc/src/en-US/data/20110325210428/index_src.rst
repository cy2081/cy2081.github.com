You can add links or bookmark with right pop up menu, or click menu   :menuselection:`New Bookmark`  from the sidebar. 

You may copy ReST text to your document for web links.

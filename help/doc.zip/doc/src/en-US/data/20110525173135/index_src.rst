:Directive Types: "attention", "caution", "danger", "error", "hint",
                  "important", "note", "tip", "warning", "admonition"
:Doctree Elements: attention, caution, danger, error, hint, important,
                   note, tip, warning, admonition, title
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as body elements.

Admonitions are specially marked "topics" that can appear anywhere an
ordinary body element can.  They contain arbitrary body elements.
Typically, an admonition is rendered as an offset block in a document,
sometimes outlined or shaded, with a title matching the admonition
type.  For example::

    .. DANGER::
       Beware killer rabbits!

This directive might be rendered something like this::

    +------------------------+
    |        !DANGER!        |
    |                        |
    | Beware killer rabbits! |
    +------------------------+

The following admonition directives have been implemented:

- attention
- caution
- danger
- error
- hint
- important
- note
- tip
- warning

Any text immediately following the directive indicator (on the same
line and/or indented on following lines) is interpreted as a directive
block and is parsed for normal body elements.  For example, the
following "note" admonition directive contains one paragraph and a
bullet list consisting of two list items::

    .. note:: This is a note admonition.
       This is the second line of the first paragraph.

       - The note contains all indented body elements
         following.
       - It includes this bullet list.


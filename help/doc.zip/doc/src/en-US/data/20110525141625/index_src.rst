.. highlight:: rst

.. versionadded:: 1.0
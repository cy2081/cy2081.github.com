:Directive Type: "sidebar"
:Doctree Element: sidebar
:Directive Arguments: One, required (sidebar title).
:Directive Options: Possible.
:Directive Content: Interpreted as the sidebar body.

Sidebars are like miniature, parallel documents that occur inside
other documents, providing related or reference material.  A sidebar
is typically offset by a border and "floats" to the side of the page;
the document's main text may flow around it.  Sidebars can also be
likened to super-footnotes; their content is outside of the flow of
the document's main text.

Sidebars may occur anywhere a section or transition may occur.  Body
elements (including sidebars) may not contain nested sidebars.

The directive's sole argument is interpreted as the sidebar title,
which may be followed by a subtitle option (see below); the next line
must be blank.  All subsequent lines make up the sidebar body,
interpreted as body elements.  For example::

    .. sidebar:: Sidebar Title
       :subtitle: Optional Sidebar Subtitle

       Subsequent indented lines comprise
       the body of the sidebar, and are
       interpreted as body elements.

The following options are recognized:

``subtitle`` : text
    The sidebar's subtitle.

``class`` : text
    Set a "classes" attribute value on the sidebar element.  See the
    class_ directive below.
